import java.io.IOException;

import cn.domoe.naivenet.Channel.NaiveNetBox;
import cn.domoe.naivenet.Channel.NaiveNetChannel;
import cn.domoe.naivenet.Channel.NaiveNetController;
import cn.domoe.naivenet.Channel.NaiveNetEvent;
import cn.domoe.naivenet.Channel.NaiveNetMessage;
import cn.domoe.naivenet.Channel.NaiveNetOnResponse;
import cn.domoe.naivenet.Channel.NaiveNetResponse;
import cn.domoe.naivenet.Channel.User;

public class MyChannel1 {

	
	private NaiveNetChannel nc;
	
	public MyChannel1(){
		
		nc = new NaiveNetChannel(5000,"abcdefg");
		
		nc.setOnNewUserListener(new NaiveNetEvent() {

			@Override
			public void on(User user, byte[] arg1) {

				
				user.setOnBreakListener(new NaiveNetEvent() {

					@Override
					public void on(User arg0, byte[] arg1) {
						System.out.println("用户断线");
						
					}
					
				});

				user.setOnRecoverListener(new NaiveNetEvent() {

					@Override
					public void on(User arg0, byte[] arg1) {
						System.out.println("用户恢复");
						
					}
					
				});
				
				user.setOnQuitListener(new NaiveNetEvent() {

					@Override
					public void on(User arg0, byte[] arg1) {
						System.out.println("用户退出");
						
					}
					
				});
				
				
				System.out.println("一个用户访问！");
				
			}
			
		});

		NaiveNetBox box = new NaiveNetBox();
		box.addController(new NaiveNetController("auth") {

			@Override
			public NaiveNetResponse onRequest(NaiveNetMessage arg0) {
				
				String data = new String(arg0.param);
				
				System.out.println(data);
				
				NaiveNetResponse res = arg0.getResponseHandler();
				
				res.setContent("Welcome to NaiveNet!");
				
				arg0.user.auth(null);
				
				
				arg0.user.setSession("id", "123".getBytes(), null);
				
				return res;
			}
			
		});
		box.addController(new NaiveNetController("t") {

			@Override
			public NaiveNetResponse onRequest(NaiveNetMessage arg0) {
				
				arg0.user.getSession("id", new NaiveNetOnResponse() {

					@Override
					public void OnComplete(int arg0, byte[] arg1) {
						
						System.out.println("GetSession:" + new String(arg1));
						
					}
					
				});
				
				return null;
			}
			
		});

		User.AddBox(box);
		
		
	}
	
	public void launch() {
		
		try {
			nc.launch();
		} catch (IOException e) {
			System.out.println("服务启动失败");
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		
		new MyChannel1().launch();;

	}

}
